package com.aks.akavya;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
Calculator c = null;
CalculatorService srv=mock(CalculatorService.class);

@BeforeEach
public void setUp() {
	c=new Calculator(srv);
}
	@Test
	void test() {
		when(srv.add(2, 3)).thenReturn(5);
		assertEquals(10,c.perform(2,3));
	}

}
