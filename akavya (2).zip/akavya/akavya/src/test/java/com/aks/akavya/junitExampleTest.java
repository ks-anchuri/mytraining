package com.aks.akavya;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class junitExampleTest {
junitexample e=new junitexample();
@BeforeEach
public void before() {
	System.out.println("before");
	
}
@AfterEach
public void after() {
	System.out.println("after");
	
}


	@Test
	 public void test() {
		int res=e.sum(new int[] {1,2,3});
		assertEquals(6,res);
		System.out.println("test");
	}
	@Test
	public void test1() {
		int k=e.sum(new int[] {1,2,3,5,8});
		assertEquals(6,k);
		System.out.println("test1");

	}

	

}
