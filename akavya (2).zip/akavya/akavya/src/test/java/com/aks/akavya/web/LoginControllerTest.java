package com.aks.akavya.web;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

//import org.assertj.core.api.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.aks.akavya.mockito.service.AuthenticationService;
import com.aks.akavya.mockito.web.LoginController;
import static org.junit.jupiter.api.Assertions.*;

public class LoginControllerTest {
private LoginController controller;
private AuthenticationService service;
@BeforeEach
public void Setup() throws Exception{
	this.service=mock(AuthenticationService.class);
	this.controller=new LoginController(this.service);
}
@Test
public void testService() {
	when(service.authenticate(anyString(),anyString() )).thenReturn(true);
	String v=controller.service("tom", "ghjhvv");
		assertNotNull(v);
	assertEquals("/home",v);
}

}
