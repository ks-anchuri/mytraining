package com.aks.akavya.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.aks.akavya.dao.UserDao;


class UserTest {
	@InjectMocks
	UserService service;
	@Mock
	UserDao dao;

	@Test
	public void test() {
		when(dao.getUserId("aks")).thenReturn("12345aks");
		String id=service.getUserIdbyname("aks");
		assertEquals("12345aks",id);
		//fail("Not yet implemented");
	}

}
