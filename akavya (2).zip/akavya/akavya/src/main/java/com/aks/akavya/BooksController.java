package com.aks.akavya;

import java.util.ArrayList;
import java.util.*;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BooksController {
	@GetMapping("/books")
	public String getAllBooks(){
		//return Arrays.asList(new Book(11,"Oracle","James"));
		Book cw=new Book(11,"Oracle","James");
		return cw.toString();
		
		
	}

}
