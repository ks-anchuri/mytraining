package com.aks.akavya.mockito.data;

import java.util.HashMap;
import java.util.Map;

import com.aks.akavya.mockito.User;

//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

public class UserRepository {
	private Map<String,User>users=new HashMap<String,User>();
	public UserRepository() {
		users.put("kavya", new User("kavya","hkvv"));
	}
	public User findByUsername(String username) {
		return users.get(username);
	}
	

}
