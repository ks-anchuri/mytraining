package com.aks.akavya;

public interface CalculatorService {

	public int add(int i, int j) ;

}
