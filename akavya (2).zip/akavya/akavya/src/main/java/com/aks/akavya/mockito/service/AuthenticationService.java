package com.aks.akavya.mockito.service;

//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

import com.aks.akavya.mockito.data.UserRepository;

public class AuthenticationService {
	private UserRepository repo;
	public boolean authenticate(String username,String password) {
		com.aks.akavya.mockito.User user=repo.findByUsername(username);
		return user.getPassword().equals(password);
	}

}
