package com.aks.akavya.mockito.web;

import com.aks.akavya.mockito.service.AuthenticationService;

public class LoginController {
	private AuthenticationService authenticationService;

	public LoginController(AuthenticationService authenticationService) {
		// TODO Auto-generated constructor stub
		this.authenticationService=authenticationService;
	}

	public String service(String username,String password) {
				return authenticationService.authenticate(username,password)?"/home":"/login";
	}

}
