package com.aks.akavya.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aks.akavya.dao.UserDao;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;
	public String getUserIdbyname(String name) {
		System.out.println("userservice called");
		return userDao.getUserId(name);
	}

}
