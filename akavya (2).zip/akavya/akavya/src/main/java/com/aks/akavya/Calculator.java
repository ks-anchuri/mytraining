package com.aks.akavya;

public class Calculator {
	CalculatorService srv;
	public Calculator(CalculatorService srv) {
		this.srv=srv;
	}
	public int perform(int i, int j) {
		return srv.add(i,j)*i;
	}

}
