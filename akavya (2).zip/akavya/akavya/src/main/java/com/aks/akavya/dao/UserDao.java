package com.aks.akavya.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	public String getUserId(String userName) {
		System.out.println("userDao called");
		return "12345" +userName;
	}
}
